   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; 2019 Online Library Management System |<a href="https://www.google.com/" target="_blank"  > Designed by : UU CSE 38A</a> 
                </div>

            </div>
        </div>
    </section>